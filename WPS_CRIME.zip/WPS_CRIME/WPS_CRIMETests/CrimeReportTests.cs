﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using WPS_CRIME;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WPS_CRIME.Tests
{
    [TestClass]
    public class CrimeReportTests
    {


        [TestMethod]
        public async Task ValidInput_Response()
        {
            // Arrange
            double latitude = 51.509865;
            double longitude = -0.118092;
            string date = "2021-01";

            // Act
            var result = await CrimeReport.GetCrimeData(latitude, longitude, date);

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public async Task InValidInput_Response()
        {
            // Arrange
            double latitude = 90.509865;
            double longitude = -0.118092;
            string date = "2021-01";

            // Act
            var result = await CrimeReport.GetCrimeData(latitude, longitude, date);

            // Assert
            Assert.IsNotNull(result);
        }


    }

}