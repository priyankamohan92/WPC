﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using static System.Net.WebRequestMethods;
//using static System.Runtime.InteropServices.JavaScript.JSType;

namespace WPS_CRIME
{
    public class CrimeReport
    {
        public static async Task Main(string[] args)
        {
            // Input
            Console.Write("Enter latitude: ");
            double latitude = double.Parse(Console.ReadLine());

            Console.Write("Enter longitude: ");
            double longitude = double.Parse(Console.ReadLine());

            Console.Write("Enter month (format: YYYY-MM): ");
            string date = Console.ReadLine();

            // Get crime data
            try
            {
                string crimeData = await GetCrimeData(latitude, longitude, date);

                DisplayCrimeCounts(crimeData);
                List<CrimeData> crimeDataList = await GetCrimeDataSummary(latitude, longitude);
                Console.Write("\n\n--------------------------------------Display Crime Summary: --------------------------------------");
                foreach (var crime in crimeDataList)
                {
                    Console.WriteLine($"\nCategory: {crime.category}, Location:[ latitude  {crime.location.latitude}, street:[ id: {crime.location.street.id}, name: {crime.location.street.name}], longitude: {crime.location.longitude}], context: {crime.context}, " +
                        $"outcome_status:[  category: {(crime.outcome_status == null ? null : crime.outcome_status.category)}, date: {(crime.outcome_status == null ? null : crime.outcome_status.date)}], , persistent_id: {crime.persistent_id}, id: {crime.id}, location_subtype: {crime.location_subtype}, month: {crime.month}");

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            finally
            {
                Console.WriteLine("Press enter to close...");
                Console.ReadLine();
            }

        }

        // Get crime data from api url.
        public static async Task<string> GetCrimeData(double latitude, double longitude, string date)
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    string apiUrl = $"https://data.police.uk/api/crimes-street/all-crime?lat={latitude}&lng={longitude}&date={date}";
                    HttpResponseMessage response = await client.GetAsync(apiUrl);
                    response.EnsureSuccessStatusCode();
                    string crimeData = await response.Content.ReadAsStringAsync();

                    if (crimeData == null || crimeData.Length == 2)
                        return null;
                    else
                        return crimeData;
                }
                catch (HttpRequestException e)
                {
                    Console.WriteLine($"Error fetching data: {e.Message}");
                    return null;
                }
            }
        }

        // Display Crime Counts grouped by category
        public static void DisplayCrimeCounts(string crimeData)
        {
            if (crimeData == null || crimeData.Length == 2)
            {
                Console.WriteLine("Unable to fetch crime data. Please check your input and try again.");
                return;
            }

            JArray crimes = JArray.Parse(crimeData);

            // Group by crime category
            var groupedCrimes = crimes.GroupBy(c => c["category"]).Select(g => new
            {
                Category = g.Key,
                Count = g.Count()
            });

            // Display summary
            Console.WriteLine("\n---------------------------------Crime Count by category listed below :---------------------------------");
            foreach (var crime in groupedCrimes)
            {
                Console.WriteLine($"{crime.Category}: {crime.Count} incidents");
            }
        }

        public static async Task<List<CrimeData>> GetCrimeDataSummary(double latitude, double longitude)
        {
            //Get the current month and year
            DateTime currentDate = DateTime.Now;
            int month = currentDate.Month;
            int year = currentDate.Year - 1; // get the last year

            using (HttpClient client = new HttpClient())
            {
                // Example URL for  crimes


                string apiUrl = $"https://data.police.uk/api/crimes-street/all-crime?lat={latitude}&lng={longitude}&date={year}-{month:00}";
                HttpResponseMessage response = await client.GetAsync(apiUrl);

                if (response.IsSuccessStatusCode)
                {

                    string responseContent = await response.Content.ReadAsStringAsync();
                    List<CrimeData> crimeDataList = JsonConvert.DeserializeObject<List<CrimeData>>(responseContent);
                   
                    return crimeDataList;
                }
                else
                {
                    throw new HttpRequestException($"API request failed with status code {response.StatusCode}");
                    return null;
                }
            }
        }


    }
}
